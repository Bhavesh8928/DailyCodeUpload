let gender = "m";
let age = 20;

if (gender == "male") {
    if (age >= 18) {
        console.log("eligible");
    }
    else {
        console.log("not eligible")
    }

}
else if (gender == "female") {
    if (age >= 18) {
        console.log("eligible");
    }
    else {
        console.log("not eligible")
    }

}
else {
    console.log("please select an option from the list")
}

let choice = 8;

switch (choice) {
    case 1: console.log("english");
        break;
    case 2: console.log("hindi");
        break;
    case 3: console.log("marathi");
        break;
    case 4: console.log("tamil");
        break;
    case 5: console.log("urdu");
        break;

default:console.log("invalid input")
}


//increment & decrement

let x=10

x=x+1 //11
x=x+10  //21
x=x+2    //23

console.log(x); //23

x=x-1;  //22
x=x-6    //16

console.log(x);   //16
let a = 1000
let c = 20
console.log((a / 100) * c)

//>
let ram_age=25
let mohan_age=27
let result=ram_age>mohan_age;

console.log(result)

let sunil_marks=36
let passing_marks=35

//method 1

console.log(sunil_marks>passing_marks);

//method 2

let result=sunil_marks>passing_marks

console.log(result);

//>=will give me output as true when the first value is bigger or equal to the second otherwise it will give me false


//>=
let a=10;
let b=10;

console.log(a>=b);



//<
//check if sunil failed or not

let sunil_marks=34;
let passing_marks=35;

console.log (sunil_marks<passing_marks)

//yes he failed


//if the purchase is of minimum 4000 only then you will get discount,check if sikander is eligible for discount or not.

let minimum_purchase=4000;
let sikander_purchase=4000;

console.log(minimum_purchase<=sikander_purchase);


let legal_age=18
let ram_age=18

console.log(legal_age<=ram_age)


//comparison operators

//double equal too ==

console.log("sumit"=="Sumit") //false
console.log("sumit"=="sumit") //true

//not equaltoo

console.log("sumit"!="Sumit") //true
console.log("sumit"!="sumit") //false

// === triple equaltoo

console.log(2=="2") //true

console.log(2==="2") //flase coz triple equaltoo checks data type

//!== not double equal too

console.log(2!=="2") //true



let a=5;
let b=6;
let c="6";
let d=-2;
let e="m";


console.log(b==c);
console.log(b===c);
console.log(a>=c );
console.log(d<=c);





if (true) {
    console.log("i am inside if conditional statement")

}

if (false) {
    console.log("i am inside if conditional statement")

}

//there are two numbers a and b 'print a is bigger'if the value of a is bigger than b

//algorithm

//if

//step1: declaring the variable 
let a = 10;
let b = 6;

//step2: declare a result variable and compare a and b
let result = a > b;

//step3: apply the if conditonal statement to get the output based on the condition getting passed
if (result) {
    console.log(a, "is bigger")
}

//if...else

let name1 = "chunnu"
let name2 = "munnu"

if (name1 == name2) {
    console.log("names are same")
}

else {
    console.log("names are different")

}


//if...else if....else

let light = "red";

if (light == "red") {
    console.log("stop")
}
else if (light == "yellow") {
    console.log("be ready/wait")
}

else {
    console.log("go!")
}

//logical operators
//and &&

let a=5
let b=2
let c=7 
let d=6

if(a>b && c>d){
  console.log("bigger")
}

else{
  console.log("no output")
}



let subject="english";
let marks="22";
let passing_marks=33;

// check if chunnu passed the english exam or not?


if(marks>=passing_marks && subject=="english"){
  console.log("passed")
}

else{
  console.log("failed")
}

// const prompt = require("prompt-sync")()
// console.log("Calculating Net Salary of the employee")
// let total;
// let gs = parseInt(prompt("Enter gross salary : "))
// let pt = parseInt(prompt("Enter Professional tax % : "))
// let pf = parseInt(prompt("Enter Provident Fund % : "))
// let it = parseInt(prompt("Enter Income tax : "))
// pt = pt*(gs/100);
// pf = pf*(gs/100);
// it = it*(gs/100);
// total = gs-pt-pf-it;
// console.log(`Total salary is : ${total}`)

// const inp = require("prompt-sync")()
// let num = parseInt(inp("Enter number : "))
// let per = parseInt(inp("Enter percentage to calculate : "))
// console.log(`The ${per}% of ${num} is ${num*(per/100)}`)

var str = "aacccehuu";
var arr = str.split("")
var temparr=[]
// console.log(arr)
var num=0;
for(let i=0;i<arr.length;i++)
{
    var count=0;
    for(let j=i;j<arr.length;j++)
    {
        if(arr[j]===arr[i])
        {
            count++;
        }
    }
    // console.log(arr[i]+" "+count)
    if(count>1)
    {
        temparr[num]=count;
        num++;
    }
}
// console.log(count)
console.log(temparr)

for(let i=0;i<arr.length;i++)
{
    var count=0;
    for(let j=i+1;j<arr.length;j++)
    {
        if(arr[j]===arr[i])
        {
            // count++;
            arr[j]=""
            arr[i]=""
        }
    }
}
console.log(arr.join('').split(""))
let same=temparr[0]


// var names=["Roshan","Sohan","Ganesh"]
// names.push("Praful")    // Insert element at last position
// names.pop()             // Removes the last element from an array
// names.shift()           // Removes first element from an array
// console.log(names)
// names.unshift("Deven","Roshan") // Inserts element from starting of an array
// console.log(names)

// var arr=[1,2,3,4,5,6]

// console.log(arr)
// for(let i=0;i<3;i++)
// {
//     arr.pop();
// }
// console.log(arr)

// for(let i=0;i<3;i++)
// {
//     console.log(arr[i])
// }

// for(let i=0;i<arr.length;i++)
// {
//     if(i===3)
//     {
//         break;
//     }
//     console.log(arr[i])
// }

// var names=["Bahubali","Spider-Man","Avengers","Iron-Man","Hulk","Thor"]

// for(let i=0;i<names.length;i++)
// {
//     if(i===2)
//     {
//         continue;
//     }
//     console.log(names[i])
// }

// for(let i=0;i<names.length;i++)
// {
//     if(i===2 || i===4)
//     {
//         continue;
//     }
//     console.log(names[i])
// }

// var products = ["earphone", "headphones", "mic", "ipad", "cell phone", "laptop"];
// var start = products.length-3;
// for(let i=start;i<products.length;i++)
// {
//     console.log(products[i])
// }

// Given an array find the unique items in the array
// let arr2 = ["Ramesh", "Suresh", "Ramesh", "Kamlesh", "Suresh","Rupak"]
// let obj={}
// for(let i=0;i<arr2.length;i++)
// {
//     let name=arr2[i];
//     console.log(name)
//   if(obj[name]==undefined)
//   {
//     console.log(obj[name])
//     obj[name]=1;
//     console.log(obj[name])
//   } 
//   else 
//   {
//     obj[name]++;
//   }
// }
// console.log(obj)

// let details={
//     name:"Roshan"
// }
// for(let key in details)
// {
//     console.log(key)
// }

// let arr = ["Ramesh", "Suresh", "Ramesh", "Kamlesh", "Suresh","Rupak"]
// console.log(arr)
// let obj={}

// for(let i=0;i<arr.length;i++)
// {
//     let name=arr[i]
//     if(obj[name]==undefined)
//     {
//         obj[name]=1;
//     }
//     else
//     {
//         obj[name]++
//     }
// }
// console.log(obj)
// for(let key in obj)
// {
//     if(obj[key]==1)
//     {
//         console.log(key)
//     }
// }
// // const sum = (a)=> a*10;
// // // sum(10)
// // console.log(sum(10))
// console.table(obj)

// let obj={}      //By Using Normal function
// function student(stid,stname,course)
// {
//     obj.StudentId = stid;
//     obj.StudentName = stname;
//     obj.Course = course;
//     // return;
// }
// student(101,"Roshan","JavaScript")
// console.log(obj)

// function student(name,course)
// {
//     this.Name = name;
//     this.Course = course;
// }
// let obj=new student("Roshan","JavaScript")
// console.log(obj)

// function student(n,a)
// {
//     let nameandage={}
//     nameandage.Name = n;
//     nameandage.Age = a;
//     return nameandage;
// }
// let obj = new student("Roshan",25)
// console.log(obj)

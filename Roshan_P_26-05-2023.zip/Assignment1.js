// function multiplyBy50(number)
// {
//     console.log(number*50);
// }
// multiplyBy50(2);

// function productOfEight(one,two,three,four,five,six,seven,eight)
// {
//     console.log(one*two*three*four*five*six*seven*eight)
// }
// productOfSix(1,2,3,4,5,6,7,8)

// function sumOfFive(one,two,three,four,five)
// {
//     console.log(one+two+three+four+five)
// }
// sumOfFive(1,2,3,4,5)

// function cubeOfNum(n)
// {
//     console.log(n*n*n)
// }
// cubeOfNum(5)

// function squareofSum(one,two,three)
// {
//     console.log((one*one)+(two*two)+(three*three))
// }
// squareofSum(1,2,3)

// function findX(x)
// {
//     console.log((x*3)+10)
// }
// findX(3)

// let a = "Roshan"
// let b = 'Ankush'
// let c = 'd'
// let d = 4
// let e = true
// let f = []
// console.log(typeof(a))
// console.log(typeof(b))
// console.log(typeof(c))
// console.log(typeof(d))
// console.log(typeof(e))
// console.log(typeof(f))

// function doubleAll(one,two,three,four)
// {
//     console.log((one*2)+(two*2)+(three*3)+(four+4))
// }
// doubleAll(1,2,3,4)

// function sevennumber(a,b,c,d,e,f,g)
// {
//     console.log((a+b+c)*(d+e+f+g))
// }
// sevennumber(1,2,3,4,5,6,7)

// function infinitystones(one,two,three,four,five,six)
// {
//     console.log(one+(two*2)+(five*2)+(six*2)+(three+three+three)+(four+four+four))
// }
// infinitystones(4,5,6,7,8,9)

// function updateandcompare(num1,num2,num3)
// {
//     function check()
//     {
//     if(num1>num2)
//     {
//         console.log("true")
//     }
//     else
//     {
//         console.log("false")
//     }
//     }
//     check();
//     num1 = num1+num3
//     check();
// }
// updateandcompare(4,5,8)

// function sumandcompare(one,two,three,four,five)
// {
//     let sum1 = one+two+three
//     let sum2 = four+five
//     if(sum1>sum2)
//     {
//         console.log(true)
//     }
//     else
//     {
//         console.log(false)
//     }
// }
// sumandcompare(1,2,3,4,5)

// function areaAndRectangle(l1,b1,l2,b2)
// {
//     let aor1 = l1*b1;
//     let aor2 = l2*b2;
//     let por1 = 2*(l1+b1);
//     let por2 = 2*(l2+b2);
//     if(aor1>aor2)
//     console.log(true)
//     else
//     console.log(false)
//     if(por1>por2)
//     console.log(true)
//     else
//     console.log(false)
// }
// areaAndRectangle(1,5,2,3)

// function cubeandsquare(n,m)
// {
//     if((n*n*n)>(m*m))
//     console.log(true)
//     else
//     console.log(false)
// }
// cubeandsquare(2,3)

// function divisibleby4(n)
// {
//     if(n%4==0)
//     console.log(`Yes`)
//     else
//     console.log(`No`)
// }
// divisibleby4(12)

// const prompt = require("prompt-sync")()
// var n = parseInt(prompt("Enter age "))
// console.log("Your age is : "+n)
// console.log(typeof(n))

// var sum="";
// for(var i=1;i<=4;i++)
// {
//     var row = ""
//     for(let j=1;j<=4;j++)
//     {
//         sum++;
//         row+=sum+" "
//     }
//     console.log(row)
// }

// var prime=true
// var num=33
// for(let i=2;i<num;i++)
// {
//     if(num%i===0)
//     {
//         prime=false
//     }
// }
// if(prime==true)
// {
//     console.log("prime")
// }
// else
// {
//     console.log("Not Prime")
// }

// var num=1;
// while(num<=10)
// {
//     num++;
//     if(num===5)
//     {
//         continue;
//     }
//     console.log(num+" : HEllo World")
// }

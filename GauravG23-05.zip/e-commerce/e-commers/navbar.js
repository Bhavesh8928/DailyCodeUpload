const Navbar=()=>{
    return`

    <nav id="navbar">
    <a href="./">
        <div> Logo</div>
        </a>
        <div>
            <a>About</a>
            <a>About</a>
            <a>About</a>
            <a href="./cart.html">Cart</a>
        </div>
    </nav>
    `
}


export default Navbar
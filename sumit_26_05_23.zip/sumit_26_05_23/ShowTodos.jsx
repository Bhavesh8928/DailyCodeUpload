import React from 'react'

const ShowTodos = ({ todos }) => {
    return (
      <div>
        {todos.map((el) => {
          return (
            <div key={el.id}>
              <h1>{el.title}</h1>
            </div>
          );
        })}
      </div>
    );
  };
export default ShowTodos

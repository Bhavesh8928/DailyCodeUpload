import React, { useState } from 'react'
import AddTodo from "./AddTodo1";
import ShowTodo from "./ShowTodos";

const Todo1 = () => {
    const[todos,settodo] = useState([])
    const handleTodo = (text) => {
      let obj = {
    id : Math.random(),
    title : text,
    status: false
    };
    settodo([...todos,obj])
    }
  return (
      <div>
      <AddTodo handleTodo={handleTodo} />
      <ShowTodo todos={todos} />
    </div>
  )
  }
export default Todo1

import React, { useState } from "react";

const AddTodo1 = ({handleTodo}) => {
    const [text, setText] = useState("")
    const handleClick = () => {
        handleTodo(text)
        setText ("")
    }
  return (
    <div>
      <input placeholder="add todo"
      value={text}
      onChange={(e) => setText(e.target.value)}
      />
      <button onClick={handleClick}>Submit</button>
    </div>
  )
}

export default AddTodo1

let page=1

const fetchData = async (page) => {
    await fetch(`https://movie-api-l3ci.onrender.com/card?_page=${page}&_limit=1`).then((res) => res.json()).then((res) => getData(res)).catch((err) => console.log(err))
}
let container=document.querySelector("#container")


const getData=(res)=>{
    container.innerHTML=""
    res.map((el)=>{
    //    console.log(el)
       let div=document.createElement("div")
       div.id="cv"
       let img=document.createElement("img")
       img.src=el.image
    
       let head=document.createElement("h1")
       head.innerText=`title:-${el.title}`
    
       let cat=document.createElement("p")
       cat.innerText=`price:-${el.price}`
    
       let fat=document.createElement("h3")
       fat.innerText=`category:-${el.category}`
    
       let dec=document.createElement("p")
       dec.innerText=`description:-${el.description}`
    
       let btn=document.createElement("button")
       btn.innerText="Delete"
       btn.addEventListener("click",()=>{
        deleteCart(el.id)
       })

       div.append(img,head,cat,fat,dec,btn)
    })
}

const deleteCart=async(el)=>{
    try {
        await fetch(`https://movie-api-l3ci.onrender.com/card/${el}`,{
            method:"DELETE"
        })
        fetchData()
        alert("deleted sucessfull")
    } catch (error) {
        alert(error)
    }
}
let nxtbtn=document.getElementById("nxt")
nxtbtn.addEventListener("click",()=>{
    page++
    fetchData(page)
})

fetchData()
let form=document.getElementById("submit")
form.addEventListener("click",async(e)=>{
   let token="vvv"
   e.preventDefault()
   let email=document.getElementById("email").Value
   let pass=document.getElementById("password").Value
   const response = await fetch("https://movie-api-l3ci.onrender.com/users");
   console.log(users)
   const user = users.find((user) => user.email === email && user.password === pass);
if(user){
    localStorage.setItem("token",token)
    alert("login sucessfully")
   }else{
    alert("pleaseSignup")
    window.location="./signup.html"
   }
})
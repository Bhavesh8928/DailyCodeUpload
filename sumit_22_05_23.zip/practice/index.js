let page=1
let fil=""
let sort=""

const fetchData = async (page,fil,sort) => {
   if(fil=="" && page==1){
    await fetch(`https://fakestoreapi.com/products`).then((res) => res.json()).then((res) => getData(res)).catch((err) => console.log(err))
   }else if(fil!=""){
    await fetch(`https://fakestoreapi.com/products/category/${fil}?sort=${sort}`).then((res)=>res.json()).then((res)=>getData(res)).catch((err)=>console.log(err))
   }
}
let container=document.querySelector("#container")

const getData=(res)=>{
  container.innerHTML=""
res.map((el)=>{
//    console.log(el)
   let div=document.createElement("div")
   div.id="cv"
   let img=document.createElement("img")
   img.src=el.image

   let head=document.createElement("h1")
   head.innerText=`title:-${el.title}`

   let cat=document.createElement("p")
   cat.innerText=`price:-${el.price}`

   let fat=document.createElement("h3")
   fat.innerText=`category:-${el.category}`

   let dec=document.createElement("p")
   dec.innerText=`description:-${el.description}`

   let btn=document.createElement("button")
   btn.innerText="AddToCart"
   btn.addEventListener("click",()=>{
    AddToCart(el)
   })
 container.append(img,head,cat,fat,dec,btn)

})
}

const AddToCart=async(el)=>{
    try {
  
  
      await fetch("https://movie-api-l3ci.onrender.com/card",{
    method:"POST",
    headers:{
      "Content-Type":"application/json"
    },
    body:JSON.stringify(el)
    
   })
   alert("Product Added To Cart")
      
    } catch (error) {
      alert(error)
    }
}


let nxtbtn=document.getElementById("nxt")
nxtbtn.addEventListener("click",()=>{
  page++
  fetchData(page,fil,sort)

})

document.getElementById("filter").addEventListener("change",()=>{
  let filter=document.getElementById("filter").value
  let val=filter
  if(val!=""){
    fil=val
   fetchData(page,fil,sort)
  }

})

document.getElementById("filter").addEventListener("change",()=>{
  let so=document.getElementById("sorting").value
  let v=so
  if(v!=""){
  fetchData(page,fil,sort)
  }
})


fetchData(page,fil,sort)

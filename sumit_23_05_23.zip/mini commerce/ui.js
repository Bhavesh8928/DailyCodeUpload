
api="https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-products"

const fetchData=async()=>{
    await fetch(api).then((res)=>res.json()).then((res)=>getData(res)).catch((err)=>console.log(err))
}

let v=document.getElementById("container")


const getData=(res)=>{
    // console.log(res)
    res.data.map((el)=>{
        let img=document.createElement("img")
        img.src=el.image
        v.append(img)
    })
}


fetchData()
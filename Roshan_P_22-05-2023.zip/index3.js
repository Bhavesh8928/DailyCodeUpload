let detail = [
    {firstName:"Roshan",lastName:"Potale",place:"Nagpur"},
    {firstName:"Sohan",lastName:"Maraskolhe",place:"Gondia"},
    {firstName:"Ganesh",lastName:"Sonkukara",place:"Nagpur"}
];
let user = detail.map(function(ele)
{
    return ele.firstName+" "+ele.lastName;
});
console.log(user);

let loc = detail.filter(function(el)
{
    return el.place=="Nagpur";
})
console.log(loc);

console.log(detail.filter(function(ele){return ele.place=="Nagpur"}).map(function(ele){return ele.firstName+" "+ele.lastName}))
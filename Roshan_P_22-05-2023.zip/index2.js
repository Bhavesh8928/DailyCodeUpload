let num = [1,2,3,4,5,6,7,8,9,10];
let num2 = [1,2,3,4,5,6];
let square = function(ele)
{
    return ele*2;
}
let res = num.map(square);
console.log(res);
let res2 = num.forEach(function(ele)
{
    console.log(ele*2);
})
console.log(res2);

let isOdd = function(ele)
{
    return ele%2==1;
}
let oddnum = num.filter(isOdd);
console.log(oddnum);
console.log(num2.map(function(el){return el}))
let product = function(ac,ele)
{
    return ac*ele;
}
let resofproduct = num2.reduce(product,1);
console.log(resofproduct);

let sumofodd = num2.filter(function(ele){return ele%2==1}).reduce(function(ac,el){return ac+el;})
console.log(sumofodd);

let sumofcube = num2.map(function(ele){return ele*ele*ele}).filter(function(el){return el%3==0;}).reduce(function(ac,el){return ac+el})
console.log(sumofcube);
function hello(s)
{
    return "Hello "+s;
}
let num = [1,2,3,4,5,6];
let names = ["Roshan","Sohan","Prateek"];

/* Retriving data by using foreach() */
console.log("----------Retriving elements by using foreach()----------")
let res1 = names.forEach(function(ele)
{
    console.log(hello(ele));
});
console.log(res1);

/* Retriving data by using map() */
console.log("----------Retriving elements by using map()----------")
let res2 = names.map(function(ele)
{
    return hello(ele);
})
console.log(res2);

/* Retriving data by using filter() */
console.log("----------Retriving elements by using filter()----------")
let res3 = num.filter(function(ele)
{
    return ele%2==0;
});
console.log(res3);

/* Retriving data by using reduce() without initial value */
console.log("----------Retriving elements by using reduce() without initial value----------")
let res4 = num.reduce(function(ac,ele)
{
    return ac+ele;
})
console.log(res4);

/* Retriving data by using reduce() with initial value */
console.log("----------Retriving elements by using reduce() with initial value----------")
let tot = function(ac,ele)
{
    return ac+ele;
}
let res5 = num.reduce(tot,10);
console.log(res5);

/* Retriving data by using reduce() with initial value */
console.log("----------Retriving elements by using reduce() with initial value----------")
let res6 = num.reduce(function(ac,ele)
{
    return ac+ele;
},100)
console.log(res6);
console.log(`----------------------------------------------------------------------------`)

let total = num.map(function(ele){return ele}).filter(function(ele){return ele%2==0}).reduce(function(ac,ele){return ac+ele});
console.log("total of even numbers between 1-6 : "+total);
